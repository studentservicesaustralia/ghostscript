== Ghostscript ==

This is a build of Ghostscript Postscript and PDF interpreter/
renderer. It is intended to make testing the latest release
easier for end users, but is not intended for use in a "live"
environment. If you find this version works better for you
either build and install from the source archive available at
http://ghostscript.com/ or lobby your distribution maintainer
to upgrade.


This Ghostscript build is a command-line tool. It is statically
linked to ensure the widest compatibility, but as a result does
not include the X11 based output devices.

Ghostscript is distributed under the terms of the GNU GPL. See the file
COPYING for details. Source code and other binaries can be obtained
from http://ghostscript.com/

GhostPCL, GhostXPS, Ghostscript and the urw font set are also
available for commercial licensing under other terms. Please visit
http://artifex.com/ for more information.
